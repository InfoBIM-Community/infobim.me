import json
from typing import Any, Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, field, fields, is_dataclass


@dataclass
class CommandResponse:
    title: str
    description: str
    content: Dict[str, Any] = field(default_factory=dict)
    severity: Optional[object] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "description": self.description,
            "content": self._serialize_response_value(self.content),
            "severity": str(getattr(self.severity, "value", self.severity))
            if self.severity is not None
            else None,
        }

    def __str__(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def _serialize_response_value(self, value: Any) -> Any:
        if is_dataclass(value) and not isinstance(value, type):
            serialized_dataclass: Dict[str, Any] = {}
            for dataclass_field in fields(value):
                serialized_dataclass[dataclass_field.name] = self._serialize_response_value(
                    getattr(value, dataclass_field.name)
                )
            return serialized_dataclass

        if isinstance(value, dict):
            serialized_dict: Dict[str, Any] = {}
            for key, item in value.items():
                serialized_dict[str(key)] = self._serialize_response_value(item)
            return serialized_dict

        if isinstance(value, (list, tuple, set)):
            return [self._serialize_response_value(item) for item in value]

        if isinstance(value, Path):
            return str(value)

        if isinstance(value, bytes):
            return value.decode("utf-8", errors="ignore")

        if hasattr(value, "to_dict") and callable(value.to_dict):
            return self._serialize_response_value(value.to_dict())

        if hasattr(value, "to_json") and callable(value.to_json):
            return self._serialize_response_value(value.to_json())

        return value


@dataclass
class InteractiveCommandResponse(CommandResponse):
    """Response whose command already rendered an interactive application."""


@dataclass
class InteractiveTreeCommandResponse(InteractiveCommandResponse):
    """Response whose command rendered an interactive collapsible tree via
    the Textual widget (Textual is a declared dependency of ontobdc).

    The command that returns this subclass is responsible for starting
    the Textual event loop itself and therefore must inherit from
    :class:`InteractiveCommandResponse`: the outer CLI shell will skip
    its own markdown/rich/static renderer so that the interactive
    surface owns the terminal.

    ``title`` and ``description`` are mirrored into the header of the
    TUI; ``content`` is the same dict the command would have returned
    for static rendering (``content["tree"]`` is the ``{name, kind,
    children}`` dict the :class:`TreeWidget` static reader already
    understands) so that piping, JSON export and downstream callers
    keep consuming identical data.
    """

    title: str = "Tree Viewer"
    description: str = "Interactive collapsible tree view."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HelpCommandResponse(CommandResponse):
    content: Dict[str, Dict[str, str]] = field(default_factory=dict)


@dataclass
class RunCommandResponse(CommandResponse):
    """Response for the ``run`` component: a resolved natural-language
    prompt. A dedicated type (rather than a generic ``CommandResponse``)
    so the terminal renderer paints it with the neutral/gray theme and a
    ``RUN`` badge instead of the default ontobdc-blue border and ``INFO``
    badge.
    """
    title: str = "OntoBDC Run"
    description: str = "Received prompt."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExceptionCommandResponse(CommandResponse):
    title: str = "Run Exception"
    description: str = "Command execution failed."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HealthCheckCommandResponse(CommandResponse):
    """Response listing the verifications a health check capability ran.

    A dedicated type so the terminal renderer paints the listing as
    outcome badges rather than as the generic key/value block every other
    dictionary content falls into.
    """

    title: str = "Health Check"
    description: str = "Verifications reported."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ListCommandResponse(CommandResponse):
    content: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class WelcomeCommandResponse(CommandResponse):
    title: str = "Welcome"
    description: str = "Display the welcome experience."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GridCommandResponse(CommandResponse):
    title: str = "Presentation Grid"
    description: str = "Visualize the terminal PresentationSurface's Tile grid."
    content: Dict[str, int] = field(default_factory=dict)


@dataclass
class GraphCommandResponse(CommandResponse):
    title: str = "Graph"
    description: str = "Visualize a graph in the terminal."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TreeCommandResponse(CommandResponse):
    title: str = "Storage Container"
    description: str = "Visualize a container's contents as a tree."
    content: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GroupedGraphCommandResponse(GraphCommandResponse):
    """A graph whose nodes/edges (see `ContextGraphAdapter`) render grouped
    by subject instead of as a node-link diagram.

    Suited to graphs that are structurally star-shaped — one subject with
    several predicate/object properties, e.g. `context.ttl`'s single
    `:CurrentContext` individual — where a network layout only produces
    overlapping boxes around one hub, and each subject read once, with its
    properties listed underneath, is the whole point.
    """

    title: str = "Graph"
    description: str = "Visualize a graph in the terminal, grouped by subject."
    content: Dict[str, Any] = field(default_factory=dict)
