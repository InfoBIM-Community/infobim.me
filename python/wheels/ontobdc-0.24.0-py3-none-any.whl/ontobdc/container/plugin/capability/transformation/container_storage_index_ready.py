from typing import Any, Dict

from ontobdc.cli.domain.port.context import CliContextPort
from ontobdc.shared.adapter.capability import TransactionCapability
from ontobdc.shared.domain.model.capability import CapabilityMetadata
from ontobdc.container.plugin.machine.container_create.state import ContainerCreateProcessState
from ontobdc.container.plugin.check.is_container_storage_index_ready.check import (
    main as check_container_storage_index_ready,
)
from ontobdc.container.plugin.check.is_container_storage_index_ready.hotfix import (
    main as hotfix_container_storage_index_ready,
)


class ContainerStorageIndexReadyCapability(TransactionCapability):
    METADATA = CapabilityMetadata(
        id="org.ontobdc.container.plugin.capability.transformation.target.container_storage_index_ready",
        version="1.0.0",
        name="Container Storage Index Ready",
        description="Ensure that storage.ttl is synchronized with the container metadata file for the target container.",
        author=["TRAE"],
        tags=["storage", "container", "create", "index"],
        supported_languages=["en", "pt-br"],
        log_message={
            "info": {
                "en": (
                    "Storage index preparation finished, and the container entry is "
                    "synchronized with its metadata file."
                ),
            },
            "debug_entry": {
                "en": (
                    "Preparing the storage index and synchronizing the "
                    "container entry with its metadata file."
                ),
            },
        },
    )

    def label(self, lang: str = "en") -> str:
        return "Container Storage Index Ready"

    def description(self, lang: str = "en") -> str:
        return "Synchronizes storage.ttl container entry with the container.ttl metadata."

    def execute(self, context: CliContextPort) -> Dict[str, Any]:
        target_path: str = str(context.get_parameter_value("container_path")).strip()
        root_path: str = str(context.root_path).strip()
        if check_container_storage_index_ready(
            container_path=target_path,
            root_path=root_path,
        ) != 0:
            if hotfix_container_storage_index_ready(
                container_path=target_path,
                root_path=root_path,
            ) != 0:
                raise ValueError("Failed to hotfix storage index entry during storage container creation.")

        if check_container_storage_index_ready(
            container_path=target_path,
            root_path=root_path,
        ) != 0:
            raise ValueError("Storage index entry is still invalid after the storage container hotfix.")

        return {
            "resulting_state": ContainerCreateProcessState.CONTAINER_STORAGE_INDEX_READY,
            "path": target_path,
        }

