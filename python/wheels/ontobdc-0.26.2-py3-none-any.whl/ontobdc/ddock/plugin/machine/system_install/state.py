from ontobdc.ddock.plugin.machine.system_install.port import (
    SystemInstallProcessStatePort,
)


class SystemInstallProcessState(SystemInstallProcessStatePort):
    """
    Enum representing the possible states of the installation of a system.
    """

    UNDEFINED = "__undefined__"
    SYSTEM_DESCRIPTOR_VALID = "__system_descriptor_valid__"
    PYTHON_DEPENDENCIES_INSTALLED = "__python_dependencies_installed__"
    DDOCK_ZIP_EXTRACTED = "__ddock_zip_extracted__"
    DDOCK_SOURCE_MOVED = "__ddock_source_moved__"
    PACKAGES_EXTRACTED = "__packages_extracted__"
    PACKAGES_HOST_MOVED = "__packages_host_moved__"
    ADDONS_MOVED = "__addons_moved__"
    CONFIG_OVERRIDDEN = "__config_overridden__"
    CONFIG_SERVER_COPIED = "__config_server_copied__"
    PYTHON_MANIFEST_UPDATED = "__python_manifest_updated__"
    SOURCE_REMOTE_RECORDED = "__source_remote_recorded__"
    SYSTEM_LOCK_WRITTEN = "__system_lock_written__"
    NODE_BUILT = "__node_built__"

    def label(self, lang: str = "en") -> str:
        labels = {
            "en": {
                self.UNDEFINED: "Undefined",
                self.SYSTEM_DESCRIPTOR_VALID: "System Descriptor Valid",
                self.PYTHON_DEPENDENCIES_INSTALLED: "Python Dependencies Installed",
                self.DDOCK_ZIP_EXTRACTED: "DDock Zip Extracted",
                self.DDOCK_SOURCE_MOVED: "DDock Source Moved",
                self.PACKAGES_EXTRACTED: "Packages Extracted",
                self.PACKAGES_HOST_MOVED: "Packages Host Moved",
                self.ADDONS_MOVED: "Addons Moved",
                self.CONFIG_OVERRIDDEN: "Config Overridden",
                self.CONFIG_SERVER_COPIED: "Config Server Copied",
                self.PYTHON_MANIFEST_UPDATED: "Python Manifest Updated",
                self.SOURCE_REMOTE_RECORDED: "Source Remote Recorded",
                self.SYSTEM_LOCK_WRITTEN: "System Lock Written",
                self.NODE_BUILT: "Node Built",
            },
            "pt-br": {
                self.UNDEFINED: "Indefinido",
                self.SYSTEM_DESCRIPTOR_VALID: "Descritor do Sistema Válido",
                self.PYTHON_DEPENDENCIES_INSTALLED: "Dependências Python Instaladas",
                self.DDOCK_ZIP_EXTRACTED: "Zip do DDock Descompactado",
                self.DDOCK_SOURCE_MOVED: "Fonte do DDock Movida",
                self.PACKAGES_EXTRACTED: "Pacotes Descompactados",
                self.PACKAGES_HOST_MOVED: "Host dos Pacotes Movido",
                self.ADDONS_MOVED: "Addons Movidos",
                self.CONFIG_OVERRIDDEN: "Configuração Sobrescrita",
                self.CONFIG_SERVER_COPIED: "Server da Configuração Copiado",
                self.PYTHON_MANIFEST_UPDATED: "Manifest Python Atualizado",
                self.SOURCE_REMOTE_RECORDED: "Remote do Fonte Gravado",
                self.SYSTEM_LOCK_WRITTEN: "Lock do Sistema Gravado",
                self.NODE_BUILT: "Node Compilado",
            },
        }
        return labels.get(lang, labels["en"]).get(self, self.value)

    def description(self, lang: str = "en") -> str:
        descriptions = {
            "en": {
                self.UNDEFINED: "Initial state before the installation has a valid system.obdc.",
                self.SYSTEM_DESCRIPTOR_VALID: "The container has a system.obdc and it is valid.",
                self.PYTHON_DEPENDENCIES_INSTALLED: "The Python dependencies of system.obdc are installed, at the versions it asks for.",
                self.DDOCK_ZIP_EXTRACTED: "The zip of ddock was downloaded and unpacked.",
                self.DDOCK_SOURCE_MOVED: "The folder of ddock that system.obdc names as source is in the container.",
                self.PACKAGES_EXTRACTED: "The zip of each package of system.obdc was downloaded and unpacked.",
                self.PACKAGES_HOST_MOVED: "The contents of src/host of each package are in the source folder of the container.",
                self.ADDONS_MOVED: "The folder each package of system.obdc names was downloaded, and the one that holds an addon was copied into the addon folder of the container.",
                self.CONFIG_OVERRIDDEN: "The override of system.obdc, when it has one, was copied to the override of asset/config.yaml of the source folder of the container.",
                self.CONFIG_SERVER_COPIED: "The server of system.obdc, when it has one, was copied to the server of asset/config.yaml of the source folder of the container, replacing all of it.",
                self.PYTHON_MANIFEST_UPDATED: "The Python dependencies of system.obdc are in the wheels of python/manifest.json of the source folder of the container, with their versions.",
                self.SOURCE_REMOTE_RECORDED: "The system.obdc says the GitHub repository the ddock was installed from.",
                self.SYSTEM_LOCK_WRITTEN: "The system.obdc.lock says what was installed.",
                self.NODE_BUILT: "The node application was compiled with npm run build.",
            },
            "pt-br": {
                self.UNDEFINED: "Estado inicial antes de a instalação ter um system.obdc válido.",
                self.SYSTEM_DESCRIPTOR_VALID: "O container tem um system.obdc e ele é válido.",
                self.PYTHON_DEPENDENCIES_INSTALLED: "As dependências Python do system.obdc estão instaladas, nas versões que ele pede.",
                self.DDOCK_ZIP_EXTRACTED: "O zip do ddock foi baixado e descompactado.",
                self.DDOCK_SOURCE_MOVED: "A pasta do ddock que o system.obdc nomeia como source está no container.",
                self.PACKAGES_EXTRACTED: "O zip de cada pacote do system.obdc foi baixado e descompactado.",
                self.PACKAGES_HOST_MOVED: "O conteúdo de src/host de cada pacote está na pasta source do container.",
                self.ADDONS_MOVED: "A pasta que cada pacote do system.obdc nomeia foi baixada, e a que tem um addon foi copiada para a pasta addon do container.",
                self.CONFIG_OVERRIDDEN: "O override do system.obdc, quando ele tem um, foi copiado para o override do asset/config.yaml da pasta source do container.",
                self.CONFIG_SERVER_COPIED: "O server do system.obdc, quando ele tem um, foi copiado para o server do asset/config.yaml da pasta source do container, substituindo tudo.",
                self.PYTHON_MANIFEST_UPDATED: "As dependências Python do system.obdc estão nos wheels do python/manifest.json da pasta source do container, com as suas versões.",
                self.SOURCE_REMOTE_RECORDED: "O system.obdc diz o repositório GitHub de onde o ddock foi instalado.",
                self.SYSTEM_LOCK_WRITTEN: "O system.obdc.lock diz o que foi instalado.",
                self.NODE_BUILT: "A aplicação node foi compilada com npm run build.",
            },
        }
        return descriptions.get(lang, descriptions["en"]).get(self, "")

    @staticmethod
    def get_state(state: str) -> "SystemInstallProcessState":
        return getattr(SystemInstallProcessState, state.upper())
