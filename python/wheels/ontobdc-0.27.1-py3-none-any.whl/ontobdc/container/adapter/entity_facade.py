from typing import Any, ClassVar, Dict, List, Optional

from rdflib import Graph, Literal, URIRef
from rdflib.namespace import DCTERMS, RDF, RDFS, XSD, Namespace

from ontobdc.shared.adapter.ontology import BrasidataCenterOntologyLibrary
from ontobdc.container.domain.exception.entity import EntityFacadeNotFoundError
from ontobdc.container.domain.model.entity_facade import (
    EntityFacade,
    EntityFacadeField,
)


class EntityFacadeLocator:
    """
    Find the facade the ontologies publish for an entity type.

    Each facade declares which entity class it is the facade of, so the
    entity is all it takes to find one.
    """

    FACADE: ClassVar[Namespace] = Namespace(
        "http://datacenter.app.br/ontology/tool/ontobdc/facade/ns.ttl#"
    )
    SCHEMA: ClassVar[Namespace] = Namespace("http://schema.org/")
    CORE: ClassVar[Namespace] = Namespace("http://datacenter.app.br/ontology/tool/ontobdc/core/ns.ttl#")

    @classmethod
    def of(cls, entity_iri: str) -> EntityFacade:
        """
        Raises:
            EntityFacadeNotFoundError: no ontology publishes a facade of
                ``entity_iri``.
            ValueError: the facade lacks something a field needs.
        """
        library: BrasidataCenterOntologyLibrary = BrasidataCenterOntologyLibrary()
        iri: str
        for iri in library.iris():
            subject: Optional[URIRef] = cls._facade_of(library.graph(iri), entity_iri)
            if subject is not None:
                # Reading the facade brings other ontologies into the graph: it works on a copy.
                return cls._read(library.graph_copy(iri), subject, entity_iri)

        raise EntityFacadeNotFoundError(
            f"No ontology publishes a facade of the entity <{entity_iri}>."
        )

    @classmethod
    def _facade_of(cls, graph: Graph, entity_iri: str) -> Optional[URIRef]:
        subject: Any
        for subject in graph.subjects(RDF.type, cls.FACADE.DataEntityFacade):
            if (subject, cls.FACADE.isFacadeOf, URIRef(entity_iri)) in graph:
                return subject if isinstance(subject, URIRef) else None

        return None

    @classmethod
    def _bring_in_fields(cls, graph: Graph, subject: URIRef) -> None:
        """
        A field the facade lists but the file of the facade does not describe is described in the
        ontology that names it: a field is an IRI, and an ontology is published at the IRI that
        names its file. Its description is read from there, so a field can be shared by the
        facades of many ontologies.
        """
        library: BrasidataCenterOntologyLibrary = BrasidataCenterOntologyLibrary()
        field_subject: Any
        for field_subject in list(graph.objects(subject, cls.FACADE.hasFacadeField)):
            if not isinstance(field_subject, URIRef) or graph.value(field_subject, cls.SCHEMA.identifier) is not None:
                continue

            graph += library.graph(str(field_subject).split("#", 1)[0])

    @classmethod
    def _read(cls, graph: Graph, subject: URIRef, entity_iri: str) -> EntityFacade:
        cls._bring_in_fields(graph, subject)
        fields: List[EntityFacadeField] = [
            cls._read_field(graph, field_subject)
            for field_subject in graph.objects(subject, cls.FACADE.hasFacadeField)
            if isinstance(field_subject, URIRef)
        ]
        return EntityFacade(
            identifier=cls._required_text(graph, subject, cls.SCHEMA.identifier),
            name=cls._label(graph, subject),
            entity_iri=entity_iri,
            creatable=cls._declared_flag(graph, subject, cls.FACADE.isCreatable),
            commentable=cls._declared_flag(graph, subject, cls.FACADE.isCommentable),
            fields=sorted(fields, key=lambda declared: declared.order),
        )

    @classmethod
    def _read_field(cls, graph: Graph, subject: URIRef) -> EntityFacadeField:
        return EntityFacadeField(
            identifier=cls._required_text(graph, subject, cls.SCHEMA.identifier),
            datatype=cls._required_text(graph, subject, cls.FACADE.fieldDatatype),
            order=int(cls._required_text(graph, subject, cls.FACADE.fieldOrder)),
            required=cls._flag(graph, subject, cls.FACADE.isRequired),
            multivalued=cls._flag(graph, subject, cls.FACADE.isMultivalued),
            maps_to_resource=cls._required_text(
                graph, subject, cls.FACADE.mapsToResource
            ),
            editable=cls._declared_flag(graph, subject, cls.FACADE.isEditable),
            default=cls._generator(graph, subject),
            default_value=cls._default_value(graph, subject),
            options=cls._options(graph, subject),
            applies_to=cls._applies_to(graph, subject),
            references_entities=cls._references_entities(graph, subject),
            applies_to_iris=sorted(str(entity_type) for entity_type in graph.objects(subject, cls.FACADE.appliesToType) if isinstance(entity_type, URIRef)),
            labels=cls._labels(graph, subject),
        )

    @classmethod
    def _labels(cls, graph: Graph, subject: URIRef) -> Dict[str, str]:
        """
        The names the facade gives the field, by lower-case language tag.
        """
        return {
            str(label.language).lower(): str(label)
            for label in graph.objects(subject, cls.SCHEMA.name)
            if isinstance(label, Literal) and label.language
        }

    @staticmethod
    def _required_text(graph: Graph, subject: URIRef, predicate: URIRef) -> str:
        value: Any = graph.value(subject, predicate)
        if value is None or not str(value).strip():
            raise ValueError(f"The facade declares no {predicate} for {subject}.")

        return str(value).strip()

    @classmethod
    def _options(cls, graph: Graph, subject: URIRef) -> List[str]:
        """
        The identifiers (``dcterms:identifier``) of the direct subclasses of the
        class the facade says the field takes its values from; none when it
        does not say so.
        """
        parent: Any = graph.value(subject, cls.FACADE.hasValuesFromSubclassesOf)
        if not isinstance(parent, URIRef):
            return []

        library: BrasidataCenterOntologyLibrary = BrasidataCenterOntologyLibrary()
        identifiers: set[str] = set()
        iri: str
        for iri in library.iris():
            ontology: Graph = library.graph(iri)
            child: Any
            for child in ontology.subjects(RDFS.subClassOf, parent):
                identifier: Any = ontology.value(child, DCTERMS.identifier)
                if isinstance(identifier, Literal):
                    identifiers.add(str(identifier))

        return sorted(identifiers)

    @classmethod
    def _references_entities(cls, graph: Graph, subject: URIRef) -> bool:
        """
        Whether the field points to entities of the container: the facade of resources
        it names is of ``DataEntity`` or of a class that some entity type is, or is a subclass of.
        """
        resource: Any = graph.value(subject, cls.FACADE.hasResourceFacade)
        if isinstance(resource, URIRef) and graph.value(resource, cls.FACADE.isFacadeOf) is None:
            # A facade of resources the file of the field does not describe is described in the ontology that names it.
            graph += BrasidataCenterOntologyLibrary().graph(str(resource).split("#", 1)[0])

        resource_class: Any = graph.value(resource, cls.FACADE.isFacadeOf) if resource is not None else None
        if not isinstance(resource_class, URIRef):
            return False

        from ontobdc.container.adapter.entity_listing import ContainerEntities

        published: List[str] = ContainerEntities._published_types()
        if str(resource_class) in published or str(resource_class) == str(cls.CORE.DataEntity):
            return True

        library: BrasidataCenterOntologyLibrary = BrasidataCenterOntologyLibrary()
        iri: str
        for iri in library.iris():
            ontology: Graph = library.graph(iri)
            if any(URIRef(entity_type) in set(ontology.transitive_subjects(RDFS.subClassOf, resource_class)) for entity_type in published):
                return True

        return False

    @classmethod
    def _applies_to(cls, graph: Graph, subject: URIRef) -> List[str]:
        """
        The identifiers (``dcterms:identifier``) of the entity types the facade
        says the field belongs to; none when it says none.
        """
        library: BrasidataCenterOntologyLibrary = BrasidataCenterOntologyLibrary()
        identifiers: set[str] = set()
        entity_type: Any
        for entity_type in graph.objects(subject, cls.FACADE.appliesToType):
            if not isinstance(entity_type, URIRef):
                continue

            iri: str
            for iri in library.iris():
                identifier: Any = library.graph(iri).value(entity_type, DCTERMS.identifier)
                if isinstance(identifier, Literal):
                    identifiers.add(str(identifier))

        return sorted(identifiers)

    @classmethod
    def _generator(cls, graph: Graph, subject: URIRef) -> Optional[str]:
        """The IRI of the value generator the facade gives the field as its default, if any."""
        generator: Any = graph.value(subject, cls.FACADE.hasDefault)
        return str(generator) if isinstance(generator, URIRef) else None

    @classmethod
    def _default_value(cls, graph: Graph, subject: URIRef) -> Optional[str]:
        """The value the facade gives the field on every instance created without one, if any."""
        value: Any = graph.value(subject, cls.FACADE.hasDefaultValue)
        return str(value) if isinstance(value, Literal) else None

    @classmethod
    def _declared_flag(cls, graph: Graph, subject: URIRef, predicate: URIRef) -> bool:
        """A flag the facade may leave out: what it does not say is false."""
        if graph.value(subject, predicate) is None:
            return False

        return cls._flag(graph, subject, predicate)

    @staticmethod
    def _flag(graph: Graph, subject: URIRef, predicate: URIRef) -> bool:
        value: Any = graph.value(subject, predicate)
        if not isinstance(value, Literal) or value.datatype != XSD.boolean:
            raise ValueError(f"The facade declares no boolean {predicate} for {subject}.")

        return bool(value.toPython())

    @classmethod
    def _label(cls, graph: Graph, subject: URIRef) -> str:
        labels: List[Any] = list(graph.objects(subject, cls.SCHEMA.name))
        label: Any
        for label in labels:
            if isinstance(label, Literal) and label.language == "en":
                return str(label)

        if not labels:
            raise ValueError(f"The facade declares no name for {subject}.")

        return str(labels[0])
